from collections import defaultdict
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from admin.api.deps import get_current_admin
from admin.api.schemas import GenericMessage
from admin.api.services import analytics_csv
from database.models import AdminUser, Delivery, MailingStat, News, Promotion, User, UserType
from database.session import get_db

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/users", response_model=GenericMessage)
async def analytics_users(
    period_days: int = 30,
    db: AsyncSession = Depends(get_db),
    admin: AdminUser = Depends(get_current_admin),
) -> GenericMessage:
    _ = admin
    now = datetime.utcnow()
    period_ago = now - timedelta(days=period_days)
    prev_period_ago = now - timedelta(days=period_days * 2)
    by_type = {
        "total": await db.scalar(select(func.count(User.id))) or 0,
        "horeca": await db.scalar(select(func.count(User.id)).where(User.user_type == UserType.HORECA)) or 0,
        "retail": await db.scalar(select(func.count(User.id)).where(User.user_type == UserType.RETAIL)) or 0,
        "new_month": await db.scalar(select(func.count(User.id)).where(User.registered_at >= period_ago)) or 0,
        "active": await db.scalar(select(func.count(User.id)).where(User.is_active.is_(True))) or 0,
        "new_previous_period": (
            await db.scalar(select(func.count(User.id)).where(User.registered_at >= prev_period_ago, User.registered_at < period_ago))
            or 0
        ),
    }
    return GenericMessage(message="ok", data=by_type)


@router.get("/content", response_model=GenericMessage)
async def analytics_content(
    db: AsyncSession = Depends(get_db),
    admin: AdminUser = Depends(get_current_admin),
) -> GenericMessage:
    _ = admin
    promo_active = await db.scalar(select(func.count(Promotion.id)).where(Promotion.is_active.is_(True))) or 0
    news_active = await db.scalar(select(func.count(News.id)).where(News.is_active.is_(True))) or 0
    deliveries_active = await db.scalar(select(func.count(Delivery.id)).where(Delivery.is_active.is_(True))) or 0
    return GenericMessage(
        message="ok",
        data={
            "promotions": await db.scalar(select(func.count(Promotion.id))) or 0,
            "news": await db.scalar(select(func.count(News.id))) or 0,
            "deliveries": await db.scalar(select(func.count(Delivery.id))) or 0,
            "promotions_active": promo_active,
            "news_active": news_active,
            "deliveries_active": deliveries_active,
        },
    )


@router.get("/cohort", response_model=GenericMessage)
async def analytics_cohort(
    db: AsyncSession = Depends(get_db),
    admin: AdminUser = Depends(get_current_admin),
) -> GenericMessage:
    _ = admin
    users = list((await db.scalars(select(User).where(User.registered_at.is_not(None)))).all())
    grouped: dict[str, int] = defaultdict(int)
    retained_7d: dict[str, int] = defaultdict(int)
    for user in users:
        key = user.registered_at.strftime("%Y-%m")
        grouped[key] += 1
        if user.last_activity and user.last_activity >= user.registered_at + timedelta(days=7):
            retained_7d[key] += 1
    rows = []
    for key, value in sorted(grouped.items()):
        retained = retained_7d.get(key, 0)
        rows.append(
            {
                "cohort": key,
                "users": value,
                "retained_7d": retained,
                "retention_7d": round((retained / value) * 100, 2) if value else 0,
            }
        )
    return GenericMessage(message="ok", data={"rows": rows})


@router.get("/conversions", response_model=GenericMessage)
async def analytics_conversions(
    db: AsyncSession = Depends(get_db),
    admin: AdminUser = Depends(get_current_admin),
) -> GenericMessage:
    _ = admin
    delivered = await db.scalar(select(func.count(MailingStat.id)).where(MailingStat.sent_at.is_not(None))) or 0
    clicked = await db.scalar(select(func.count(MailingStat.id)).where(MailingStat.clicked_at.is_not(None))) or 0
    conversion = round((clicked / delivered) * 100, 2) if delivered else 0
    return GenericMessage(message="ok", data={"delivered": delivered, "clicked": clicked, "conversion_rate": conversion})


@router.get("/export")
async def analytics_export(
    db: AsyncSession = Depends(get_db),
    admin: AdminUser = Depends(get_current_admin),
) -> StreamingResponse:
    _ = admin
    rows = {
        "users_total": await db.scalar(select(func.count(User.id))) or 0,
        "users_horeca": await db.scalar(select(func.count(User.id)).where(User.user_type == UserType.HORECA)) or 0,
        "users_retail": await db.scalar(select(func.count(User.id)).where(User.user_type == UserType.RETAIL)) or 0,
        "content_active": (
            (await db.scalar(select(func.count(Promotion.id)).where(Promotion.is_active.is_(True))) or 0)
            + (await db.scalar(select(func.count(News.id)).where(News.is_active.is_(True))) or 0)
            + (await db.scalar(select(func.count(Delivery.id)).where(Delivery.is_active.is_(True))) or 0)
        ),
    }
    return StreamingResponse(iter([analytics_csv(rows)]), media_type="text/csv")
